package ProClaming2018;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class AirTile extends Tile{
	int x, y;
	private final String TYPE = "Air";
	private boolean isDug = true;
	private BufferedImage sprite;
	public AirTile() throws IOException{
		sprite = ImageIO.read(new File("src\\airTile.png"));
	}

	public int Dig(){
		return 3;
	}
	public boolean isDug() {
		return isDug;
	}
	public String tileType() {
		return TYPE;
	}
	public String toString(){
		return TYPE + " " + isDug;
	}

	public void Draw(int x, int y, Graphics g, boolean playerNear) {
		
		g.drawImage(sprite, x, y, 50, 50, null);
		
	}

	@Override
	public void isDugmaketrue() {
		// TODO Auto-generated method stub
		
	}
}
