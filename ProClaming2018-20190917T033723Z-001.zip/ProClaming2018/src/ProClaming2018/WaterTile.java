package ProClaming2018;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class WaterTile extends Tile{
	int x, y;
	private final String TYPE = "WATER";
	private boolean isDug = false;
	private BufferedImage sprite;
	public WaterTile() throws IOException{
		sprite = ImageIO.read(new File("src\\groundTile.png"));
	}
	public int Dig() {
		return 2;
	}

	public boolean isDug() {
		return false;
	}
	public String tileType() {
		return TYPE;
	}
	public String toString(){
		return TYPE + " " + isDug;
	}

	public void Draw(int x, int y, Graphics g, boolean playerNear) {
		g.drawImage(sprite, x, y, 50, 50, null);
		
	}
	public void isDugmaketrue() {
		
	}
}
