package ProClaming2018;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
//this originally had an image that poped up to tell you what the rules were but I changed it to a j option pane so it makes a lot less sense to have it as its own class now
public class helpMenu implements Helpmenuinterface{
	private final String INSTRUCTIONS = "Clams are scattered throughout the map, press space when your clam rake is over the desired tile to dig on it.\n"
			+ " Clams may or may not show themselves when you walk by, so don't be scared to dig randomly.\n"
			+ " It should be noted that there are invisible water tiles scattered around the map and you might hit one digging randomly,\n"
			+ " this will cause you to lose a life. You should also beware the tide you have only a few minutes to collect as many clams as you can.\n"
			+ " When you think you have collected all the calms you can for map you have,\n"
			+ " Press space on an air tile to proceed to the next area. once you go to the next area you cannot go back.\n"
			+ " The taxi driver will also want 2 of your hard earned clams before he takes you to the next area";


	public String getinformation() {
		return INSTRUCTIONS;
	}
	public void displayinfo() {
		JOptionPane.showConfirmDialog(null, INSTRUCTIONS);
	}
}
