package ProClaming2018;

import java.awt.Container;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

public class ProClaming extends JFrame implements JavaArcade{

	private static final long serialVersionUID = 1L;
	mainThinggy p;
	public ProClaming() throws IOException{
		BufferedImage image = ImageIO.read(new File("src\\IconImage.png"));
		JFrame ProClamming = new JFrame();
		ProClamming.setTitle("ProClamming 2018 Limited Edition");
		ProClamming.setIconImage(image);
		ProClamming.setResizable(false);
		ProClamming.setSize(750,675);
		ProClamming.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		p = new mainThinggy();
		Container pane = ProClamming.getContentPane();
		pane.add(p);
		ProClamming.setVisible(true);
		p.requestFocus();
	}
	public static void main(String[] args) throws IOException{
		ProClaming pc = new ProClaming();
	}
	public boolean running() {
		
		return p.timerRunning();
	}
	public void startGame() {
		p.start();
	}
	public String getGameName() {
		return "Pro-Clamming Simulator 2018 edition";
	}
	public void pauseGame() {
		p.pause();	
	}
	public String getInstructions() {
		return p.hm.getinformation();
	}
	public String getCredits() {
		return "Quincy Mattor";
	}
	public String getHighScore() {
		try {
			return p.GetHighScore() + "";
		} catch (FileNotFoundException e) {
			return null;
		}
	}
	public void stopGame() {
		p.pause();
	}
	public int getPoints() {
		return p.player.score;
	}
}
