package ProClaming2018;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
//just a relitivly standard player class
public class Player {
	private int movingtimer = 5;
	private boolean movingbool = true;
	private int lives;
	private int XPosition;
	private int YPosition;
	private int XStart;
	private int YStart;
	public int score;
	BufferedImage CharModel;
	BufferedImage MovingCharModel;
	private boolean faceleft = false;
	
	public Player(int xStart, int yStart, int livenum) throws IOException{
		CharModel = ImageIO.read(new File("src\\charmodle .png"));
		MovingCharModel = ImageIO.read(new File("src\\charmodlemoving.png"));
		XStart = xStart;
		YStart = yStart;
		XPosition = xStart;
		YPosition = yStart;
		lives = livenum;
	}
	public String getLives(){
		return "" + lives;
	}
	//player loses life method
	public void playerDie() throws FileNotFoundException{
		lives--;
		if(lives<=0){
			doubledogDie();
		}
		XPosition = XStart;
		YPosition = YStart;
	}
	//2 different methods of dying for 2 different ways, wasn't sure how you wanted me to handle the game ending, so I left it with the programaticle nuke of System.exit
	private void doubledogDie() throws FileNotFoundException{
		FileReader fr = new FileReader(new File("src//highscore.txt"));
		Scanner scanner = new Scanner(fr);
		int highScore =scanner.nextInt();
		if(score>highScore){
			PrintWriter pw = new PrintWriter(new File("src//highscore.txt"));
			pw.write("" + score);
			pw.close();
		}
		JOptionPane.showConfirmDialog(null, "you fell in a sink hole and died, your score was " + score);
		System.exit(0);
	}
	public void timedeath() throws FileNotFoundException{
		FileReader fr = new FileReader(new File("src//highscore.txt"));
		Scanner scanner = new Scanner(fr);
		int highScore =scanner.nextInt();
		if(score>highScore){
			PrintWriter pw = new PrintWriter(new File("src//highscore.txt"));
			pw.write("" + score);
			pw.close();
		}
		JOptionPane.showConfirmDialog(null, "the tide came in and washed away the rest of the clams, your score was " + score);
		System.exit(0);
	}
	//methods for moving the character
	public void moveRight(){
		if(!(XPosition + 10 >740))
		XPosition += 10;
		faceleft = false;
	}
	public void moveLeft(){
		if(!(XPosition - 10 <10))
		XPosition-= 10;
		faceleft = true;
	}
	public void moveUp(){
		if(!(YPosition - 10 <50))
		YPosition-= 10;
	}
	public void moveDown(){
		if(!(YPosition + 10 >600))
		YPosition+= 10;
	}
	//player coordinate getters
	public int getXpos(){
		return XPosition;
	}
	public int getYpos(){
		return YPosition;
	}
	/*
	 *handles everything to do with drawing, also draws it in a way that the clam rake (the hook thing on the hand) is the center
	 *of the charicter model, just to make it intuitive for the player to understand the character's hitbox
	 */
	public void Draw(Graphics g, boolean moving){
		if(moving){
			if(movingbool){
				if(faceleft){
					g.drawImage(MovingCharModel, XPosition+50, YPosition -50, -50, 100, null);
					movingtimer--;
				}else{
					g.drawImage(MovingCharModel, XPosition - 50, YPosition -50, 50, 100, null);
					movingtimer--;
				}
				if(movingtimer < 0){
					movingbool = false;
					movingtimer = 5;
					}
				}
			else{
				if(faceleft){
					g.drawImage(CharModel, XPosition+50, YPosition-50, -50, 100, null);
					movingtimer--;
				}else{
					g.drawImage(CharModel, XPosition-50, YPosition-50, 50, 100, null);
					movingtimer--;
				}
				if(movingtimer < 0){
					movingbool = true;
					movingtimer = 5;
					}
				}
		}else{
			if(faceleft){
				g.drawImage(CharModel, XPosition+50, YPosition-50, -50, 100, null);
			}else{
				g.drawImage(CharModel, XPosition-50, YPosition-50, 50, 100, null);
			}
		}
	}
	
}
