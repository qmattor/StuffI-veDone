package ProClaming2018;

import java.awt.Graphics;
import java.io.IOException;
import java.util.ArrayList;
// this handles creation of maps and tile management
public class map {
	private ArrayList<Tile> map = new ArrayList<Tile>();
	public map() throws IOException{		// randomly creates map. The top 60 tiles are always sky tiles
		for(int x = 0; x<60; x++){
			AirTile at = new AirTile();
			map.add(x, at);
		}
		for(int x = 60; x <200; x++){
			double z = Math.random();
			if(z <= .1){
				RockTile rt = new RockTile();
				map.add(x, rt);
			}
			if(z > .1 && z <= .2){
				ClamTile ct = new ClamTile();
				map.add(x, ct);
			}
			if(z > .2 && z <= .25){
				WaterTile wt = new WaterTile();
				map.add(x, wt);
			}
			if(z>.25 && z<= 1){
				GroundTile gt = new GroundTile();
				map.add(x, gt);
			}
		}
		}
	// returns the tile that the player is currently on
	public Tile getCurrentTile(int x, int y){
		for(int z = 0; z <map.size(); z++){
			if(x - map.get(z).x < 50 && y - map.get(z).y < 50){
				return map.get(z);
			}
		}
		return null;
		
	}
	//draws the map, the x and y variable names were fliped and I never bothered to fix it, that bug was really confusing
	public void draw(Graphics g, int playerx, int playery){
		int z = 0;
		for(int x = 0; x <map.size()/15; x++){
			for(int y = 0; y < 15; y++){
				if( Math.abs(y*50 - playerx) <= 50 && Math.abs(x*50 - playery) <= 50){
					map.get(z).Draw(y*50, x*50, g, true);
					map.get(z).x = y*50;
					map.get(z).y = x*50;
				}else{
					map.get(z).Draw(y*50, x*50, g, false);
					map.get(z).x = y*50;
					map.get(z).y = x*50;
				}
				z++;
			}
		}
	}
	
}
