package ProClaming2018;

public interface Helpmenuinterface {
	public String getinformation();
	public void displayinfo();
}
