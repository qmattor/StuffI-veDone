package ProClaming2018;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Font;

public class mainThinggy extends JPanel implements ActionListener, KeyListener {
	
	private static final long serialVersionUID = 1L;
	private Timer t;
	private map m;
	private boolean playerleft = false, playerright = false, playerup = false, playerdown = false;
	Player player;
	helpMenu hm;
	int TimeLimit = 7200;							// 6 min total == 7200
	public mainThinggy() throws IOException{
		hm = new helpMenu();
		t = new Timer(50, this);
		player = new Player(50, 50, 3); //x spawn position, y spawn position, number of lives the player starts with
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		m = new map();
		t.start();
	}
	//these are the methods are for the java arcade interface methods
	public boolean timerRunning(){
		return t.isRunning();
	}
	public void start(){
		t.start();
	}
	public void pause(){
		t.stop();
	}
	public void resume(){
		t.start();
	}
	public String GetHighScore() throws FileNotFoundException{
		FileReader fr = new FileReader(new File("src//highscore.txt"));
		Scanner scanner =new Scanner(fr);
		return scanner.nextLine();
	}
	//repaint method
	public void actionPerformed(ActionEvent e){
		repaint();
	}
	//paintcomponent
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		TimeLimit--;
		if(TimeLimit < 0){			//when timer runs out, player loses remaining lives
			t.stop();
			try {
				player.timedeath();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
		m.draw(g, player.getXpos(), player.getYpos());
		//this uses a method of using booleans to keep the player movement smooth
		if(playerleft){
			player.moveLeft();
		}
		if(playerright){
			player.moveRight();
		}
		if(playerup){
			player.moveUp();
		}
		if(playerdown){
			player.moveDown();
		}
		//sets font to something actually visible to the human eye
		g.setFont(new Font("Serif", Font.BOLD, 18));
		//draws lives and player information
		g.drawString("your score is : " + player.score, 500, 25);
		g.drawString("you have " +player.getLives() + " left", 500, 50);
		g.drawString("you have " + (TimeLimit)/10 + " time left", 500, 75);
		g.drawString("press f1 for help", 50, 25);
		if(playerleft || playerright || playerdown || playerup){
			player.Draw(g, true);
		}else{
			player.Draw(g, false);
		}
		
		
	}
	
	public void keyPressed(KeyEvent arg0) {
		switch(arg0.getKeyCode()){
		case KeyEvent.VK_A:{
			playerleft = true;
			break;
		}
		case KeyEvent.VK_D:{
			playerright = true;
			break;
		}
		case KeyEvent.VK_W:{
			playerup = true;
			break;
		}
		case KeyEvent.VK_S:{
			playerdown = true;
			break;
		}
		//space does EVERYTHING
		case KeyEvent.VK_SPACE:{
			if(m.getCurrentTile(player.getXpos(), player.getYpos()).Dig() == 2){
				try {
					player.playerDie();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
				}else if(m.getCurrentTile(player.getXpos(), player.getYpos()).Dig() == 1){
				m.getCurrentTile(player.getXpos(), player.getYpos()).isDugmaketrue();
				player.score++;
				}else if(m.getCurrentTile(player.getXpos(), player.getYpos()).Dig() == 3){
					try {
						map x = new map();
						m = x;
						player.score -= 2;
					} catch (IOException e) {
					}
					
				}
			break;
			}
		case KeyEvent.VK_F1:{
			hm.displayinfo();
			break;
		}
		
		}
	}
	public void keyReleased(KeyEvent arg0) {
		switch(arg0.getKeyCode()){
		case KeyEvent.VK_A:{
			playerleft = false;
			break;
		}
		case KeyEvent.VK_D:{
			playerright = false;
			break;
		}
		case KeyEvent.VK_W:{
			playerup = false;
			break;
		}
		case KeyEvent.VK_S:{
			playerdown = false;
			break;
		}
		
		}
	}
	public void keyTyped(KeyEvent arg0) {
		
	}
}
