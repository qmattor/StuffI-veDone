package ProClaming2018;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class GroundTile extends Tile{
	int x, y;
	private final String TYPE = "Ground";
	private boolean isDug;
	private BufferedImage sprite;
	public GroundTile() throws IOException{
		sprite = ImageIO.read(new File("src\\groundTile.png"));
	}
	public int Dig(){
		isDug = true;
		return 0;
	}

	@Override
	public boolean isDug(){
		return isDug;
	}
	public String tileType(){
		return TYPE;
	}
	public String toString(){
		return TYPE + " " + isDug;
	}
	public void Draw(int x, int y, Graphics g, boolean playerNear) {
		g.drawImage(sprite, x, y, 50, 50, null);
		
	}
	public void isDugmaketrue() {
	}
}
