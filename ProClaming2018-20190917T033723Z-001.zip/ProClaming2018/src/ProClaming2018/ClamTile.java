package ProClaming2018;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class ClamTile extends Tile{
	private final String TYPE = "CLAM";
	public boolean isDug = false;
	private BufferedImage csprite;
	private BufferedImage gsprite;
	double v;
	public ClamTile() throws IOException{
		csprite = ImageIO.read(new File("src\\clamTile.png"));
		gsprite = ImageIO.read(new File("src\\groundTile.png"));
		v = Math.random();
	}
	public int Dig() {
		if(isDug){
			return 0;
		}else{
			return 1;
		}
	}
	public boolean isDug() {
		return isDug;
	}
	public void isDugmaketrue() {
		isDug = true;
	}
	public String tileType() {
		return TYPE;
	}
	public String toString(){
		return TYPE + " " + isDug;
	}


	public void Draw(int x, int y, Graphics g, boolean playerNear) {
		if(isDug){
			g.drawImage(gsprite, x, y, null);
		}else{

			if(playerNear && v > .5){
				g.drawImage(csprite, x, y, 50, 50, null);
			}else{
				g.drawImage(gsprite, x, y, null);
			}
		}
			
		
	}

}
