package ProClaming2018;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class RockTile extends Tile{
	int x, y;
	private final String TYPE = "Rock";
	private boolean isDug = false;
	private BufferedImage sprite;
	public RockTile() throws IOException{
		sprite = ImageIO.read(new File("src\\stoneTile.png"));
	}
	public int Dig() {
		return 0;
	}

	public boolean isDug() {

		return false;
	}

	public String tileType() {
		return null;
	}
	public String toString(){
		return TYPE + " " + isDug;
	}

	public void Draw(int x, int y, Graphics g, boolean playerNear) {
		
		g.drawImage(sprite, x, y, 50, 50, null);
		
	}
	@Override
	public void isDugmaketrue() {
		// TODO Auto-generated method stub
		
	}
}
