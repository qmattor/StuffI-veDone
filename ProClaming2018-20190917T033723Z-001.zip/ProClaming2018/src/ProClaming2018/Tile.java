package ProClaming2018;

import java.awt.Graphics;
//this class is polymorphic as it is used to define multiple tile classes
//also this would have been an interface but I needed the variables in here for ease, so it became a class
public abstract class Tile {
	int x, y;
	private String TYPE;
	private boolean isDug;
	public abstract boolean isDug();
	public abstract String tileType();
	public abstract void Draw(int x, int y, Graphics g, boolean playerNear);
	public abstract int Dig();
	public abstract void isDugmaketrue();//this didn't fit but it was an easy fix so I left in here
}
